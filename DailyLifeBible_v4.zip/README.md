
Daily Life Bible - Complete Android Studio Project (v4)
------------------------------------------------------

This project includes:
- Full Bible (English + Portuguese) stored in SQLite
- Verse-level bookmarks, highlights, and notes
- Daily Verse notifications with devotionals
- Share-as-image feature (dark + gold modern style)
- Custom golden cross app icon and dark splash screen

Instructions:
1. Open this folder in Android Studio
2. Build & run the project on an Android device
3. All features are ready to use

Notes:
- To compile an APK, use Build -> Build Bundle(s) / APK(s) -> Build APK(s)
- Daily notifications use WorkManager; ensure notifications are enabled on the device
